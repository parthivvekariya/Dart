<?php

    include('../connect.php');
    
    $name = $_POST["name"];
    $number = $_POST["number"];
    $address = $_POST["address"];
    $password = $_POST["password"];


    if($name=="" && $number=="" && $address=="" && $password=="")
    {
        
        echo '0';
        
    }
    else
    {
     
    $sql ="insert into one_stop_users(name,number,address,password) values ('$name','$number','$address','$password')";
        mysqli_query($con,$sql);//query run
        
    }


?>