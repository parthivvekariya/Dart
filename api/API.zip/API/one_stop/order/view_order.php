<?php
header('Content-Type: application/json');
include('../connect.php');

// Get the order ID from the URL parameter
$orderId = isset($_GET['orderId']) ? intval($_GET['orderId']) : 0;

if ($orderId > 0) {
    // Fetch the order details
    $orderQuery = $con->prepare("SELECT * FROM orders WHERE id = ?");
    $orderQuery->bind_param("i", $orderId);
    $orderQuery->execute();
    $orderResult = $orderQuery->get_result();

    if ($orderResult->num_rows > 0) {
        $order = $orderResult->fetch_assoc();

        // Fetch the order items
        $itemsQuery = $con->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $itemsQuery->bind_param("i", $orderId);
        $itemsQuery->execute();
        $itemsResult = $itemsQuery->get_result();

        $items = [];
        while ($item = $itemsResult->fetch_assoc()) {
            $items[] = $item;
        }

        $response = [
            'status' => 'success',
            'order' => $order,
            'items' => $items
        ];
    } else {
        $response = [
            'status' => 'error',
            'message' => 'Order not found'
        ];
    }

    $orderQuery->close();
    $itemsQuery->close();
} else {
    $response = [
        'status' => 'error',
        'message' => 'Invalid order ID'
    ];
}

$con->close();
echo json_encode($response);
?>
