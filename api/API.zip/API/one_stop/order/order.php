<?php
header('Content-Type: application/json');
include('../connect.php');

// Get the JSON input from the client
$input = json_decode(file_get_contents('php://input'), true);

if ($input) {
    $number = $input['number'];
    $name = $input['name'];
    $address = $input['address'];
    $items = $input['items'];
    $paymentMethod = $input['paymentMethod'];
    $deliveryOption = $input['deliveryOption'];
    $orderNotes = $input['orderNotes'];

    // Insert the order into the orders table
    $stmt = $con->prepare("INSERT INTO orders (number, name, address, paymentMethod, deliveryOption, orderNotes) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $number, $name, $address, $paymentMethod, $deliveryOption, $orderNotes);

    if ($stmt->execute()) {
        $orderId = $stmt->insert_id;

        // Insert each item into the order_items table
        $stmt = $con->prepare("INSERT INTO order_items (order_id, item_id, item_name, quantity, total_price) VALUES (?, ?, ?, ?, ?)");
        foreach ($items as $item) {
            $itemId = $item['itemId'];
            $itemName = $item['itemName'];
            $quantity = $item['quantity'];
            $totalPrice = $item['totalPrice'];

            $stmt->bind_param("iisid", $orderId, $itemId, $itemName, $quantity, $totalPrice);
            $stmt->execute();
        }

        $response = [
            'status' => 'success',
            'message' => 'Order placed successfully'
        ];
    } else {
        $response = [
            'status' => 'error',
            'message' => 'Failed to place order: ' . $stmt->error
        ];
    }

    $stmt->close();
} else {
    $response = [
        'status' => 'error',
        'message' => 'Invalid input'
    ];
}

$con->close();
echo json_encode($response);
?>
