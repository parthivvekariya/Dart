<?php

    include('../connect.php');
    $sql = "SELECT * FROM one_stop_item";
    $r = mysqli_query($con,$sql);
    $response = array();
    
    While($row = mysqli_fetch_array($r))
    {
        $value["id"] = $row["id"];
        $value["category_id"] = $row["category_id"];
        $value["item_image"] = $row["item_image"];
        $value["item_name"] = $row["item_name"];
        $value["item_price"] = $row["item_price"];
        $value["item_quantity"] = $row["item_quantity"];
        
        array_push($response,$value);
        
    }
    
    echo json_encode($response);
    mysqli_close($con);


?>