<?php

    include('../connect.php');
    $sql = "SELECT * FROM one_stop_Categorie";
    $r = mysqli_query($con,$sql);
    $response = array();
    
    While($row = mysqli_fetch_array($r))
    {
        $value["id"] = $row["id"];
        $value["Categorie_image"] = $row["Categorie_image"];
        $value["Categorie_name"] = $row["Categorie_name"];
        //$value["value"] = $row["value"];
        
        array_push($response,$value);
        
    }
    
    echo json_encode($response);
    mysqli_close($con);


?>