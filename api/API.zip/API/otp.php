<?php

header('Content-Type: application/json');

// Path to store OTPs
define('OTP_STORE', 'otp_store.json');

// Generate a random OTP
function generateOTP($length = 6) {
    $otp = '';
    for ($i = 0; $i < $length; $i++) {
        $otp .= mt_rand(0, 9);
    }
    return $otp;
}

// Save OTP to store
function saveOTP($phone, $otp) {
    $data = file_exists(OTP_STORE) ? json_decode(file_get_contents(OTP_STORE), true) : [];
    $data[$phone] = [
        'otp' => $otp,
        'timestamp' => time()
    ];
    file_put_contents(OTP_STORE, json_encode($data));
}

// Verify OTP
function verifyOTP($phone, $otp) {
    if (!file_exists(OTP_STORE)) {
        return false;
    }
    $data = json_decode(file_get_contents(OTP_STORE), true);
    if (isset($data[$phone]) && $data[$phone]['otp'] == $otp) {
        return true;
    }
    return false;
}

// Handle request
$request_method = $_SERVER['REQUEST_METHOD'];

if ($request_method == 'POST') {
    $request_body = json_decode(file_get_contents('php://input'), true);
    $action = $request_body['action'] ?? null;
    $phone = $request_body['phone'] ?? null;

    if ($action == 'generate' && $phone) {
        $otp = generateOTP();
        saveOTP($phone, $otp);
        echo json_encode(['status' => 'success', 'message' => 'OTP generated', 'otp' => $otp]);
    } elseif ($action == 'verify' && $phone) {
        $otp = $request_body['otp'] ?? null;
        if (verifyOTP($phone, $otp)) {
            echo json_encode(['status' => 'success', 'message' => 'OTP verified']);
        } else {
            echo json_encode(['status' => 'fail', 'message' => 'Invalid OTP']);
        }
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'Invalid request']);
    }
} else {
    echo json_encode(['status' => 'fail', 'message' => 'Invalid request method']);
}

?>
